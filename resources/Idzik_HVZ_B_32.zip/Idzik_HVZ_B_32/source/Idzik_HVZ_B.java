import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Idzik_HVZ_B extends PApplet {

ArrayList<Human> humans = new ArrayList(); //Create an ArrayList of humans
ArrayList<Zombie> zombies = new ArrayList(); //Create an ArrayList of zombies
Obstacle[] obst = new Obstacle[10]; //Create an array of obstacles
Collision collide = new Collision(); //Create a Collision object
Vectors vect = new Vectors(); //Create a Vectors object
boolean showVectors = false; //Boolean for showing vectors
PImage background; //Background

public void setup() //Set up the initial screen
{
   //Set up the screen size
  for (int i = 0; i < 10; i++) //Loop to create the humans and obstacles
  {
    obst[i] = new Obstacle(new PVector((int)random(25, width - 50), (int)random(25, width - 50))); //Create a new obstacle object
    humans.add(new Human((int)random(25, width - 50), (int)random(25, height - 50), 16, 2, 0.1f, obst)); //Create a new human object and add it to the list
  }
  zombies.add(new Zombie(width / 2, height / 2, 16, 1, 0.1f, obst)); //Create a new zombie object and add it to the list
  background = loadImage("Background.png"); //Load the background
  ellipseMode(CENTER); //Set ellipses to be drawn from the center
  shapeMode(CENTER); //Set shapes to be drawn from the center
  imageMode(CENTER); //Set images to be drawn from the center
}

public void draw()
{
  background(255); //Set the background

  stroke(0); //Set the outline color
  image(background, width / 2, height / 2); //Set the background

  for (int i = 0; i < humans.size(); i++) //For all of the zombies in the list
  {
    humans.get(i).Update(); //Update the humans
    humans.get(i).Display(); //Draw the humans
  }

  for (int i = 0; i < zombies.size(); i++) //For all of the humans in the list
  {
    zombies.get(i).Update(); //Update the zombies
    zombies.get(i).Display(); //Draw the zombies
  }

  for (int i = 0; i < 10; i++) //Loop to display the obstacles
  {
    obst[i].Display(); //Draw the obstavles
  }

  collide.Detect(humans, zombies, obst); //Detect collisions between the humans and zombies

  vect.Display(showVectors, humans, zombies); //Display the vectors
}

public void keyPressed() //If a key is pressed
{
  if (key == ' ' && showVectors == false) //If space is pressed and vectors are not showing
  {
    showVectors = true; //Show vectors
  } else if (key == ' ' && showVectors == true) //If space is pressed and vectors are showing
  {
    showVectors = false; //Hide vectors
  }
}

public void mousePressed() //If the mouse is pressed
{
  if (mouseButton  == LEFT) //If the left button is clicked
  {
    humans.add(new Human(mouseX, mouseY, 16, 2, 0.1f, obst)); //Create a new human object and add it to the list
  }
  if (mouseButton  == RIGHT) //If the right button is clicked
  {
    zombies.add(new Zombie(mouseX, mouseY, 16, 1, 0.1f, obst)); //Create a new zombie object and add it to the list
  }
  if (mouseButton  == CENTER) //If the right button is clicked
  {
    humans.add(new Human((int)random(25, width - 50), (int)random(25, height - 50), 16, 2, 0.1f, obst)); //Create a new human object and add it to the list
    zombies.add(new Zombie((int)random(25, width - 50), (int)random(25, height - 50), 16, 1, 0.1f, obst)); //Create a new zombie object and add it to the list
  }
}
class Collision //Collision class
{
  Collision() //Constructor
  {
  }

  public void Detect(ArrayList<Human> hmn, ArrayList<Zombie> zomb, Obstacle[] obst) //Detect and resolve collisions
  {
    for (int i = 0; i < hmn.size(); i++) //Search throught the list of humans
    {
      for (int j = 0; j < zomb.size(); j++) //Search throught the list of zombies
      {
        if (hmn.size() == 0) //If there are no humans in the list
        {
          break; //Break out of the loop
        }

        Human currentHuman = hmn.get(i); //Set the current human
        Zombie currentZombie = zomb.get(j); //Set the current zombie

        if (PVector.sub(currentHuman.position, currentZombie.position).mag() < 15) //If the zombie catches the human
        {
          zomb.add(new Zombie(currentHuman.position.x, currentHuman.position.y, 16, 1, 0.1f, obst)); //Make the human a zombie and add it to the list
          hmn.remove(currentHuman); //Remove the human from the list

          Zombie lastZombie = zomb.get(zomb.size() - 1); //Get the last zombie in the list
          Zombie firstZombie = zomb.get(0); //Get the first zombie in the list
          lastZombie.target = firstZombie.target.copy(); //Set the target of the last zombie to the target of the first zombie
        }

        if (i + 1 > hmn.size()) //If the next value in the list of humans has been removed
        {
          i = 0; //Reset the loop
        }
      }
    }
  }
}
class Human extends Vehicle //Human class, inherited from Vehicle
{
  PVector target = null; //Target to seek

  PImage body; //PImage to draw this seeker object

  PVector steeringForce; //Steering force

  PVector distFromZombToHum; //Distance from the zombie to the human

  Zombie currentZombie; //The current zombie

  Obstacle[] obst = new Obstacle[10]; //Obstacle to avoid

  Human(float x, float y, float r, float ms, float mf, Obstacle[] obt) //Constructor
  {   
    super(x, y, r, ms, mf); //Call the super class' constructor and pass in necessary arguments
    steeringForce = new PVector(0, 0); //Instantiate steeringForce vector to (0, 0)

    int randomColorInt = (int)random(0, 6); //Create a random number for skin colors

    if (randomColorInt == 0) //If the random number is 0
    {
      fill(255, 218, 190); //Set the fill color for the humans
    } else if (randomColorInt == 1) //If the random number is 1
    {
      fill(255, 195, 170); //Set the fill color for the humans
    } else if (randomColorInt == 2) //If the random number is 2
    {
      fill(240, 184, 160); //Set the fill color for the humans
    } else if (randomColorInt == 3) //If the random number is 3
    {
      fill(210, 164, 140); //Set the fill color for the humans
    } else if (randomColorInt == 4) //If the random number is 4
    {
      fill(135, 103, 90); //Set the fill color for the humans
    } else if (randomColorInt == 5) //If the random number is 5
    {
      fill(75, 57, 50); //Set the fill color for the humans
    }

    body = loadImage("Human.png"); //PImage initialization
    target = new PVector((int)random(25, width - 50), (int)random(25, height - 50)); //Draw the seeker "pointing" toward 0 degrees
    obst = obt; //Set the obstacle object
  }

  public void CalcSteeringForces() //Calculates the forces required to steer the human
  {  
    PVector evadeForce = new PVector(0, 0); //Evading vector
    PVector wanderForce = new PVector(0, 0); //Wandering vector

    for (int i = 0; i < zombies.size(); i++) //Search throught the list of zombies
    {
      currentZombie = zombies.get(i); //Set the current zombie

      distFromZombToHum = PVector.sub(position, currentZombie.position); //Get the distance from the zombie to the human

      if (distFromZombToHum.mag() < 100) //If the human is within 100 pixels of the zombie and in front of it
      {
        maxSpeed = 2; //Change the max speed
        evadeForce = Evade(currentZombie); //The humans's target is away from the zombie
        steeringForce.add(evadeForce); //Add the evading force to the steering force
      } else
      {
        maxSpeed = .75f; //Change the max speed
        wanderForce = Wander();
      }
    }

    PVector seekingForce = Seek(target).mult(-1); //Get the steering force returned from calling seek to flee

    if ((position.x < 35 || position.x > 465 || position.y < 35 || position.y > 465)) //If the human is out of bounds
    {
      target = new PVector(width / 2, height / 2); //Target the center of the screen
      seekingForce = Seek(target).mult(1000); //Get the steering force returned from calling seek
    }

    steeringForce.add(seekingForce); //Add the above seeking force to this overall steering force

    steeringForce.add(wanderForce); //Add the wandering force to the overall steering force

    PVector avoidingForce; //Vector for avoiding obstacles

    for (int i = 0; i < 10; i++) //Loop to track the obstacles
    {
      avoidingForce = AvoidObstacle(obst[i], 25); //Force for avoiding obstacles
      steeringForce.add(avoidingForce); //Add the above avoiding force to this overall steering force
    }

    steeringForce.limit(maxForce); //Limit this seeker's steering force to a maximum force

    ApplyForce(steeringForce); //Apply this steering force to the vehicle's acceleration

    steeringForce = new PVector(0, 0); //Reset the steering force to 0
  }

  public void Display() //Display the human
  {
    float angle = velocity.heading(); //Calculate the direction of the current velocity

    pushMatrix(); //Push the matrix
    translate(position.x, position.y); //Translate the image
    rotate(angle + PI/2); //Rotate the seeker
    image(body, 0, 0); //Draw the image
    popMatrix(); //Pop the matrix
  }
}
class Obstacle //Obstacle class
{
  int radius; //Radius of the obstacle

  PVector position; //Position of the obstacle

  PImage tree; //Obstacle

  Obstacle(PVector pos) //Constructor
  {
    fill(185, 100, 0); //Set the fill color

    position = pos; //Set the position of the first obstacle

    radius = 32; //Set the radius of the obstacle

    tree = loadImage("Tree.png"); //Create the obstacle
  }

  public void Display() //Draws the obstacles
  {
    image(tree, position.x, position.y); //Draw the obstacle
  }
}
class Vectors //Vectors class
{
  Vectors() //Constructor
  {
  }

  public void Display(boolean showVectors, ArrayList<Human> hmn, ArrayList<Zombie> zomb) //Draw the vectors to the screen
  {
    if (showVectors == true) //If vectors should be drawn
    {
      fill(0); //Set the fill color
      textSize(20); //Change the font size
      text("VECTOR MODE", 185, 20); //Draw text
      for (int i = 0; i < hmn.size(); i++) //Search throught the list of humans
      {
        Human currentHuman = hmn.get(i); //Get the current human
        if (currentHuman.futurePos != null && currentHuman.distFromZombToHum.mag() < 100) //If the future position of the human is not null
        {
          stroke(255); //Set the outline color for the target of the current human
          line(currentHuman.position.x, currentHuman.position.y, currentHuman.futurePos.x, currentHuman.futurePos.y); //Current human pursuit path
        }
        stroke(255, 0, 0); //Set the outline color for the forward vector of the current human
        line(currentHuman.position.x, currentHuman.position.y, currentHuman.position.x + 20*currentHuman.forward.x, currentHuman.position.y + 20*currentHuman.forward.y); //Forward vector of the current human
        stroke(0, 255, 0); //Set the outline color for the right vector of the current human
        line(currentHuman.position.x, currentHuman.position.y, currentHuman.position.x + 20*currentHuman.right.x, currentHuman.position.y + 20*currentHuman.right.y); //Right vector of the current human
      }
      for (int j = 0; j < zomb.size(); j++) //Search throught the list of zombies
      {
        Zombie currentZombie = zomb.get(j); //Get the current zombie
        if (currentZombie.futurePos != null) //If the future position of the zombie is not null
        {
          stroke(0); //Set the outline color for the target of the current zombie
          line(currentZombie.position.x, currentZombie.position.y, currentZombie.futurePos.x, currentZombie.futurePos.y); //Current zombie pursuit path
        }
        stroke(255, 0, 0); //Set the outline color for the forward vector of the current zombie
        line(currentZombie.position.x, currentZombie.position.y, currentZombie.position.x + 20*currentZombie.forward.x, currentZombie.position.y + 20*currentZombie.forward.y); //Forward vector of the current zombie
        stroke(0, 255, 0); //Set the outline color for the right vector of the current zombie
        line(currentZombie.position.x, currentZombie.position.y, currentZombie.position.x + 20*currentZombie.right.x, currentZombie.position.y + 20*currentZombie.right.y); //Right vector of the current zombie
      }
    }
  }
}
abstract class Vehicle //Vehicle class
{
  PVector acceleration; //Acceleration PVector
  PVector velocity; //Velocity PVector
  PVector position; //Position PVector

  PVector forward; //Forward PVector
  PVector right; //Right PVector

  float posX; //Vehicle X position
  float posY; //Vehicle Y position
  float radius; //Vehicle radius
  float maxSpeed; //Vehicle max speed
  float maxForce; //Vehicle max force
  float mass; //Vehicle mass

  PVector desiredVelocity; //The desired velocity of the seeker
  PVector steer; //Steering vector

  PVector futurePos; //Future position of the target

  Vehicle(float x, float y, float r, float ms, float mf) //Constructor
  {
    posX = x; //Assign the vehicle X position
    posY = y; //Assign the vehicle Y position
    radius = r; //Assign the vehicle radius
    maxSpeed = ms; //Assign the vehicle mas speed
    maxForce = mf; //Assign the vehicle max force
    mass = 1; //Assign the vehicle mass

    forward = new PVector(0, 0); //Initialize forward
    right = new PVector(0, 0); //Initialize right
    acceleration = new PVector(0, 0); //Initialize acceleration
    velocity = new PVector(0, 0); //Initialize velocity
    position = new PVector(posX, posY); //Initialize position
  }

  public abstract void CalcSteeringForces(); //Abstract CalcSteeringForces method
  public abstract void Display(); //Abstract Display method

  public void Update() //Calculates the overall steering force
  { 
    CalcSteeringForces(); //Calculate steering forces by calling CalcSteeringForces()

    velocity.add(acceleration); //Add acceleration to velocity, limit the velocity, and add velocity to position
    velocity.limit(maxSpeed);
    position.add(velocity);

    forward = velocity.copy(); //Calculate the forward vector
    forward.normalize(); //Normalize the forward vector
    right.x = -forward.y; //Take the forward unit vector and make it perpendicular
    right.y = forward.x; //Take the forward unit vector and make it perpendicular

    acceleration = new PVector(0, 0); //Reset acceleration
  }

  public void ApplyForce(PVector force) //Applies the force to the vehicle
  {
    acceleration.add(PVector.div(force, mass)); //Divide the force by the mass of the vehicle and add that force to the acceleration vector
  }

  public PVector Seek(PVector target) //Find the a steering force for the position of the target
  {
    desiredVelocity = PVector.sub(target, position); //Subtract the target position from the seeker position

    desiredVelocity.normalize(); //Normalize the desired velocity

    desiredVelocity.mult(maxSpeed); //Set the magnitude of the desired velocity to maxSpeed

    steer = PVector.sub(desiredVelocity, velocity); //Calculate the steering vector

    steer.limit(maxSpeed); //Limit the steering force

    return steer; //Return the steering force
  }

  public PVector Pursue(Human target) //Pursue based on the future position of the target
  {
    PVector currentPos = target.position.copy(); //Copy the current position of the human
    PVector currentVel = target.velocity.copy(); //Copy the current velocity of the human

    futurePos = PVector.add(currentPos, currentVel.mult(10)); //Get the position of the target 10 frames from now

    PVector pursueForce = Seek(futurePos); //Seek the future position

    return pursueForce.mult(4); //Return the pursuit force
  }

  public PVector Evade(Zombie target) //Evade based on the future position of the target
  {
    PVector currentPos = target.position.copy(); //Copy the current position of the zombie
    PVector currentVel = target.velocity.copy(); //Copy the current velocity of the zombie

    futurePos = PVector.add(currentPos, currentVel.mult(5)); //Get the position of the target 5 frames from now

    PVector evadeForce = Seek(futurePos); //Seek the future position

    return evadeForce.mult(-3); //Return the pursuit force
  }

  public PVector Wander() //Method for wandering
  { 
    PVector circleCenter = velocity.copy(); //Copy the velocity of the vehicle
    circleCenter.normalize(); //Normalize the vector for the circle
    circleCenter.mult(2); //Multiply 

    PVector displacement = new PVector(0, 0); //Create a displacement PVector

    float wanderAngle = randomGaussian() * 6; //Set the wander angle
    displacement.rotate(radians(wanderAngle)); //PVector to change the vector direction

    PVector wanderForce = new PVector (0, 0); //Force to be returned
    wanderForce = circleCenter.add(displacement); //Return the force as the center of the circle plus the displacement
    return wanderForce; //Return the wandering force
  }
  
  public PVector AvoidObstacle(Obstacle obst, int safeRadius) //Avoid obstacles
  {
    steer = new PVector(0, 0); //Create a new PVector to be returned later

    PVector vecToObst = PVector.sub(obst.position, position); //Get a vector from the character to the obstacle

    float distToObst = vecToObst.mag(); //Find the distance to the obstacle

    float safeZone = safeRadius + radius + obst.radius; //Set a safe zone based on the radius of the seeker, obstacle, and safeRadius

    if (distToObst > safeZone) //If the distance between the seeker and obstacle is larger than the safe radius
    {
      return steer; //Return the steering vector
    }

    if (vecToObst.dot(forward) < 0) //If the dot product of the vector from the character to the obstacle and the forward vector is negative (Behind the seeker)
    {
      return steer; //Return the steering vector
    }

    float distSeekCentToObstCent = vecToObst.dot(right); //Use the dot product to find the distance between the center of the seeker and the center of the obstacle

    if (abs(distSeekCentToObstCent) > obst.radius + radius) //If the distance between the centers of the seeker and obstacle are greater than the radii of the obstacle and seeker
    {
      return steer; //Return the steering vector
    }

    if (distSeekCentToObstCent >= 0) //To avoid an obstacle on the right
    {
      right = PVector.mult(right, -1); //Make the right vector negative
      desiredVelocity = PVector.mult(right, maxSpeed); //Multiply the right vector by the max speed
    }
    if (distSeekCentToObstCent < 0) //To avoid an obstacle on the left
    {
      desiredVelocity = PVector.mult(right, maxSpeed); //Multiply the right vector by the max speed
    }

    steer = PVector.sub(desiredVelocity, velocity); //Calculate the steering force

    if (distToObst <= 25) //If the seeker is close to the obstacle
    {
      mass = 4; //Mass is 4
    }     
    if (distToObst > 25 && distToObst <= 50) //If the seeker is mid distance to the obstacle
    {
      mass = 2; //Mass is 2
    }
    if (distToObst > 50) //If the seeker is far from the obstacle
    {
      mass = 1; //Mass is 1
    }

    steer.mult(mass); //Multiply the steering force by the mass of the obstacle

    return steer; //Return the steering force
  }
}
class Zombie extends Vehicle //Zombie class, inherited from Vehicle
{
  PVector target = null; //Target to seek

  PImage body; //PImage to draw this seeker object

  PVector steeringForce; //Steering force

  int avoidRadius = 100; //Avoidance radius

  Obstacle[] obst = new Obstacle[10]; //Obstacle to avoid

  Zombie(float x, float y, float r, float ms, float mf, Obstacle[] obt) //Constructor
  {        
    super(x, y, r, ms, mf); //Call the super class' constructor and pass in necessary arguments
    steeringForce = new PVector(0, 0); //Instantiate steeringForce vector to (0, 0)
    fill(0, 255, 100); //Set the fill color for the zombies
    body = loadImage("Zombie.png"); //PImage initialization
    target = new PVector(width / 2, height / 2); //Draw the seeker "pointing" toward 0 degrees
    obst = obt; //Set the obstacle object
  }

  public void CalcSteeringForces() //Calculates the forces required to steer the zombie
  {
    for (int i = 0; i < humans.size(); i++) //Search throught the list of humans
    {
      Human currentHuman = humans.get(i); //Set the current human

      if (PVector.sub(currentHuman.position, position).mag() < avoidRadius) //If the human is within 100 pixels of the zombie
      {            
        PVector pursueForce = Pursue(currentHuman); //The zombie's target is the human

        avoidRadius = (int)PVector.sub(currentHuman.position, position).mag(); //Set the search radius to the magnitude of the current human and zombie

        steeringForce.add(pursueForce); //Add the above seeking force to this overall steering force
      } else //If no humans are within range
      {
        avoidRadius = 100; //Rest the avoid radius
      }
    }

    PVector seekingForce = new PVector(0, 0); //Get the steering force returned from calling seek

    if (position.x < 25 || position.x > 475 || position.y < 25 || position.y > 475) //If the zombie is out of bounds
    {
      target = new PVector(width / 2, height / 2); //Set a new target
      seekingForce = Seek(target); //Steer to center of the screen
    }

    steeringForce.add(seekingForce); //Add the above seeking force to this overall steering force

    PVector avoidingForce; //Vector for avoiding obstacles

    for (int i = 0; i < 10; i++) //Loop to track the obstacles
    {
      avoidingForce = AvoidObstacle(obst[i], 25); //Force for avoiding obstacles
      steeringForce.add(avoidingForce); //Add the above avoiding force to this overall steering force
    }

    steeringForce.limit(maxForce); //Limit this seeker's steering force to a maximum force

    ApplyForce(steeringForce); //Apply this steering force to the vehicle's acceleration

    steeringForce = new PVector(0, 0); //Reset the steering force to 0
  }

  public void Display() //Display the zombie
  {
    float angle = velocity.heading(); //Calculate the direction of the current velocity

    pushMatrix(); //Push the matrix
    translate(position.x, position.y); //Translate the image
    rotate(angle + PI/2); //Rotate the seeker
    image(body, 0, 0); //Draw the image
    popMatrix(); //Pop the matrix
  }
}
  public void settings() {  size(500, 500); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Idzik_HVZ_B" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
