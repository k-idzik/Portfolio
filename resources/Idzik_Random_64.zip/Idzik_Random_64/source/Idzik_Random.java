import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Idzik_Random extends PApplet {

boolean jump = false; //Should the MoonMan jump
boolean shoot = false; //Has the Laser been fired
boolean reload = false; //Is the Laser reloading
int X = 0; //The X coordinate of the MoonMan
int Y = 264; //The Y coordinate of the MoonMan
MoonMan mMan = new MoonMan(X, Y); //Create a MoonMan object
Laser lser = new Laser(X, mMan); //Create a Laser object
Terrain train = new Terrain(640, 32); //Create a Terrain object
Rocks dwayne = new Rocks(700, 328); //Create a Rocks object
Collision coll = new Collision(mMan, lser, dwayne); //Create a collision object
Score scre = new Score(mMan, lser, dwayne); //Create a Score object

public void setup() //Sets up the screen for use
{
   //Change the size of the window
  background(0); //Set the background color to black
  train.Create(); //Create the terrain
}

public void draw() //Draws the screen
{
  train.Display(); //Draw the terrain
  lser.Reloading(reload); //Draw the reloading text
  mMan.Display(); //Draw the MoonMan
  mMan.Jump(jump); //Draw the MoonMan when he jumps
  lser.FireLaser(shoot); //Draw the Laser when shooting
  dwayne.Display(); //Draw the Rocks
  coll.Detect(); //Detect collisions
  scre.KeepScore(); //Keep score
}

public void keyPressed() //When keys are pressed
{
  if (key == ' ' && mMan.posY == Y) //If the key is space
  {
    jump = true; //MoonMan jumps
  }

  if (keyCode == ENTER) //If the key is enter
  {
    reload = false; //The Laser is not reloading
    shoot = true; //The Laser fires
  }
}

public void keyReleased() //When keys are released
{
  if (key == ' ') //If the key is space
  {
    jump = false; //MoonMan stops jumping
  }

  if (keyCode == ENTER && lser.moveX >= 640) //If the key is enter
  {
    reload = true; //The Laser is reloading
    shoot = false; //The Laser is not firing
  }
}
class Collision //Collision class
{
  MoonMan moonM; //MoonMan object
  Laser lser; //Laser object
  Rocks rock; //Rock object

  Collision(MoonMan mMan, Laser lsr, Rocks rck) //Constructor
  {
    moonM = mMan; //Import the MoonMan object
    lser = lsr; //Import the Laser object
    rock = rck; //Import the Rocks object
  }

  public void Detect() //Detect collisions
  {
    if (moonM.posX + 56 < rock.moveX && moonM.posY + 64 < rock.posY - 48) //If the MoonMan and Rocks have not collided
    {
      moonM.collide = false; //Collision is false
      rock.collide = false; //Collision is false
    }
    if (moonM.posX + 56 >= rock.moveX && moonM.posY + 64 >= rock.posY - 48) //If the MoonMan and Rocks have collided
    {
      moonM.collide = true; //Collision is true
      rock.collide = true; //Collision is true
    }

    if (lser.moveX + lser.randomSize < rock.moveX && lser.posY + 4 < rock.posY - 48) //If the Laser and Rocks have not collided
    {
      lser.collide = false; //Collision is false
      rock.collide = false; //Collision is false
    }
    if (lser.moveX + lser.randomSize >= rock.moveX && lser.posY + 4 >= rock.posY - 48 && rock.moveRock == true) //If the Laser and Rocks have collided
    {
      lser.collide = true; //Collision is true
      rock.collide = true; //Collision is true
    }
  }
}
class Laser //Laser class
{
  int posX; //X coordinate of the Laser
  int posY = 0; //Y coordinate of the Laser
  int moveX; //To move in the X direction
  int frameTimer = 0; //The timer to change the frames for shooting
  float randomSpeed; //The speed at which the Laser moves
  float randomSize; //The size of the Laser
  MoonMan moonM; //MoonMan object
  boolean collide = false; //If the Laser has collided with something

  Laser(int x, MoonMan mMan) //Constructor
  {
    posX = x + 40; //Set the X coordinate
    moveX = posX; //Set the initial moveX coordinate
    moonM = mMan; //Set the MoonMan object
  }

  public void FireLaser(boolean doShoot) //Makes the Laser fire
  {
    noStroke(); //Turn off outlines
    fill(200, 0, 0); //Set the fill color

    if (doShoot == true && moveX < 640) //If the Laser should fire
    {
      if (moveX == posX) //If the Laser is in it's initial X position
      {
        posY = moonM.posY + 40; //Set the Y position of the Laser
      }

      if (randomSize <= 0) //When the size of the Laser has not been set in the first run
      {
        SetGaussian(); //Set the size of the Laser
      }
      rect(moveX, posY, randomSize, 4); //Draw the Laser

      if (randomSpeed <= 0) //When the speed of the Laser has not been set in the first run
      {
        SetGaussian(); //Set the speed of the Laser
      }
      moveX += randomSpeed; //Move the Laser
    }

    if (doShoot == true && frameTimer == 0) //If the Laser is firing
    {
      moonM.frame = -15; //Set the MoonMan to the shooting frame
      frameTimer++; //Increment the frameTimer
    }

    if (collide == true) //If the Laser has hit something
    {
      moveX = 640; //Move the Laser to the end of the screen
      collide = false; //Set collide to false
    }

    if (collide == false && moveX >= 640) //If the Laser has hit something
    {
      posY = 0; //Move the Laser to the top of the screen
    }

    if (doShoot == false && moveX >= 640) //If the Laser should not fire
    {
      moveX = posX; //Reset moveX
      posY = 0; //Move the Laser to the top of the screen
      frameTimer--; //Reset the frameTimer
    }
  }

  public void Reloading(boolean rld) //If the Laser is reloading
  {
    if (rld == true) //If the Laser is reloading
    {
      SetGaussian(); //Set the Gaussian values of the Laser
      fill(255); //Set the fill color
      textSize(24);
      text("RELOADING", (width / 2) - 65, height / 2); //Write the text
    }
  }

  public void SetGaussian() //Set the Gaussian values of the Laser
  {
    randomSpeed = (randomGaussian() + 1) * 4; //Randomly determines the speed of the Laser
    randomSize = (randomGaussian() + 2) * 8; //Randomly determines the size of the Laser

    if (randomSpeed < 0) //If the speed of the Laser is negative
    {
      randomSpeed *= -1; //Make the speed positive
    }
    if (randomSpeed > 0 && randomSpeed < .5f) //If the speed of the Laser is between 0 and .5
    {
      randomSpeed += 1; //Add 1 to the speed of the Laser
    }

    if (randomSize < 0) //If the size of the Laser is negative
    {
      randomSize *= -1; //Make the size positive
    }
    if (randomSize > 0 && randomSize < 4) //If the size of the Laser is between 0 and 4
    {
      randomSize += 4; //Add 4 to the size of the Laser
    }

    randomSpeed = Math.round(randomSpeed); //Round the speed of the Laser to the nearest integer
    randomSize = Math.round(randomSize); //Round the size of the Laser to the nearest integer
  }
}
class MoonMan //MoonMan class
{
  int posX; //X coordinate of the MoonMan
  int posY; //Y coordinate of the MoonMan
  int maxJump; //The maximum jump height
  int frame = 0; //Which frame of the MoonMan to show
  boolean collide = false; //If the MoonMan has collided with something

  MoonMan(int x, int y) //Constructor
  {
    posX = x; //Set the X coordinate
    posY = y; //Set the Y coordinate
    maxJump = y - 128; //Set the maximum jump height
  }

  public void Display() //Draws the MoonMan
  {
    noStroke(); //Turns off outlines

    if (frame >= -15 && frame < 0) //The shooting frames
    {
      //Helmet
      fill(245); //Set the fill color
      rect(posX + 12, posY, 40, 4); //Draw a piece of the helmet
      rect(posX + 8, posY + 4, 8, 20); //Draw a piece of the helmet
      rect(posX + 16, posY + 4, 4, 4); //Draw a piece of the helmet
      rect(posX + 16, posY + 20, 4, 4); //Draw a piece of the helmet
      rect(posX + 48, posY + 4, 4, 4); //Draw a piece of the helmet
      rect(posX + 52, posY + 4, 4, 20); //Draw a piece of the helmet
      rect(posX + 48, posY + 20, 4, 4); //Draw a piece of the helmet
      rect(posX + 12, posY + 24, 40, 4); //Draw a piece of the helmet

      //Visor Glint
      rect(posX + 24, posY + 8, 4, 4); //Draw a piece of the visor glint

      //Visor Glint
      fill(210); //Set the fill color
      rect(posX + 24, posY + 12, 4, 4); //Draw a piece of the visor glint

      //Visor
      fill(215, 215, 0); //Set the fill color
      rect(posX + 20, posY + 4, 28, 4); //Draw a piece of the visor
      rect(posX + 16, posY + 8, 8, 12); //Draw a piece of the visor
      rect(posX + 28, posY + 8, 24, 12); //Draw a piece of the visor
      rect(posX + 24, posY + 16, 4, 4); //Draw a piece of the visor
      rect(posX + 20, posY + 20, 28, 4); //Draw a piece of the visor

      //Suit
      fill(225); //Set the fill color
      rect(posX + 20, posY + 28, 24, 4); //Draw a piece of the suit
      rect(posX + 16, posY + 32, 32, 4); //Draw a piece of the suit
      rect(posX + 20, posY + 36, 16, 4); //Draw a piece of the suit
      rect(posX + 40, posY + 36, 4, 4); //Draw a piece of the suit
      rect(posX + 20, posY + 40, 24, 16); //Draw a piece of the suit
      rect(posX + 20, posY + 56, 8, 4); //Draw a piece of the suit
      rect(posX + 36, posY + 56, 8, 4); //Draw a piece of the suit

      //Suit Arms
      fill(195); //Set the fill color
      rect(posX + 16, posY + 36, 4, 8); //Draw a suit arm
      rect(posX + 20, posY + 44, 4, 4); //Draw a suit arm
      rect(posX + 44, posY + 36, 4, 12); //Draw a suit arm

      //Gloves
      fill(115); //Set the fill color
      rect(posX + 24, posY + 44, 4, 4); //Draw a glove
      rect(posX + 44, posY + 48, 4, 4); //Draw a glove

      //Boots
      rect(posX + 20, posY + 60, 12, 4); //Draw a boot
      rect(posX + 36, posY + 60, 12, 4); //Draw a boot

      //Suit Badge
      fill(150, 0, 0); //Set the fill color
      rect(posX + 36, posY + 36, 4, 4); //Draw the badge

      //Laser Gun
      fill(0); //Set the fill color
      rect(posX + 24, posY + 48, 4, 4); //Draw a piece of the Laser Gun
      rect(posX + 24, posY + 40, 16, 4); //Draw a piece of the Laser Gun

      frame++; //Increment frame
    }

    if (frame >= 0 && frame < 15) //The first set of frames
    {
      //Helmet
      fill(245); //Set the fill color
      rect(posX + 12, posY, 40, 4); //Draw a piece of the helmet
      rect(posX + 8, posY + 4, 8, 20); //Draw a piece of the helmet
      rect(posX + 16, posY + 4, 4, 4); //Draw a piece of the helmet
      rect(posX + 16, posY + 20, 4, 4); //Draw a piece of the helmet
      rect(posX + 48, posY + 4, 4, 4); //Draw a piece of the helmet
      rect(posX + 52, posY + 4, 4, 20); //Draw a piece of the helmet
      rect(posX + 48, posY + 20, 4, 4); //Draw a piece of the helmet
      rect(posX + 12, posY + 24, 40, 4); //Draw a piece of the helmet

      //Visor Glint
      rect(posX + 24, posY + 8, 4, 4); //Draw a piece of the visor glint

      //Visor Glint
      fill(210); //Set the fill color
      rect(posX + 24, posY + 12, 4, 4); //Draw a piece of the visor glint

      //Visor
      fill(215, 215, 0); //Set the fill color
      rect(posX + 20, posY + 4, 28, 4); //Draw a piece of the visor
      rect(posX + 16, posY + 8, 8, 12); //Draw a piece of the visor
      rect(posX + 28, posY + 8, 24, 12); //Draw a piece of the visor
      rect(posX + 24, posY + 16, 4, 4); //Draw a piece of the visor
      rect(posX + 20, posY + 20, 28, 4); //Draw a piece of the visor

      //Suit
      fill(225); //Set the fill color
      rect(posX + 20, posY + 28, 24, 4); //Draw a piece of the suit
      rect(posX + 16, posY + 32, 32, 4); //Draw a piece of the suit
      rect(posX + 20, posY + 36, 16, 4); //Draw a piece of the suit
      rect(posX + 40, posY + 36, 4, 4); //Draw a piece of the suit
      rect(posX + 20, posY + 40, 24, 16); //Draw a piece of the suit
      rect(posX + 16, posY + 52, 4, 4); //Draw a piece of the suit
      rect(posX + 16, posY + 56, 8, 4); //Draw a piece of the suit
      rect(posX + 36, posY + 56, 8, 4); //Draw a piece of the suit

      //Suit Arms
      fill(195); //Set the fill color
      rect(posX + 16, posY + 36, 4, 12); //Draw a suit arm
      rect(posX + 44, posY + 36, 4, 8); //Draw a piece of the suit arm
      rect(posX + 48, posY + 44, 4, 4); //Draw a piece of the suit arm

      //Gloves
      fill(115); //Set the fill color
      rect(posX + 16, posY + 48, 4, 4); //Draw a glove
      rect(posX + 52, posY + 48, 4, 4); //Draw a glove

      //Boots
      rect(posX + 12, posY + 52, 4, 12); //Draw a boot
      rect(posX + 36, posY + 60, 12, 4); //Draw a boot

      //Suit Badge
      fill(150, 0, 0); //Set the fill color
      rect(posX + 36, posY + 36, 4, 4); //Draw the badge

      frame++; //Increment frame
    }

    if (frame >= 15 && frame < 30) //The second set of frames
    {
      //Helmet
      fill(245); //Set the fill color
      rect(posX + 12, posY, 40, 4); //Draw a piece of the helmet
      rect(posX + 8, posY + 4, 8, 20); //Draw a piece of the helmet
      rect(posX + 16, posY + 4, 4, 4); //Draw a piece of the helmet
      rect(posX + 16, posY + 20, 4, 4); //Draw a piece of the helmet
      rect(posX + 48, posY + 4, 4, 4); //Draw a piece of the helmet
      rect(posX + 52, posY + 4, 4, 20); //Draw a piece of the helmet
      rect(posX + 48, posY + 20, 4, 4); //Draw a piece of the helmet
      rect(posX + 12, posY + 24, 40, 4); //Draw a piece of the helmet

      //Visor Glint
      rect(posX + 24, posY + 8, 4, 4); //Draw a piece of the visor glint

      //Visor Glint
      fill(210); //Set the fill color
      rect(posX + 24, posY + 12, 4, 4); //Draw a piece of the visor glint

      //Visor
      fill(215, 215, 0); //Set the fill color
      rect(posX + 20, posY + 4, 28, 4); //Draw a piece of the visor
      rect(posX + 16, posY + 8, 8, 12); //Draw a piece of the visor
      rect(posX + 28, posY + 8, 24, 12); //Draw a piece of the visor
      rect(posX + 24, posY + 16, 4, 4); //Draw a piece of the visor
      rect(posX + 20, posY + 20, 28, 4); //Draw a piece of the visor

      //Suit
      fill(225); //Set the fill color
      rect(posX + 20, posY + 28, 24, 4); //Draw a piece of the suit
      rect(posX + 16, posY + 32, 32, 4); //Draw a piece of the suit
      rect(posX + 20, posY + 36, 16, 4); //Draw a piece of the suit
      rect(posX + 40, posY + 36, 4, 4); //Draw a piece of the suit
      rect(posX + 20, posY + 40, 24, 16); //Draw a piece of the suit
      rect(posX + 20, posY + 56, 8, 4); //Draw a piece of the suit
      rect(posX + 36, posY + 56, 8, 4); //Draw a piece of the suit

      //Suit Arms
      fill(195); //Set the fill color
      rect(posX + 16, posY + 36, 4, 12); //Draw a suit arm
      rect(posX + 44, posY + 36, 4, 12); //Draw a suit arm

      //Gloves
      fill(115); //Set the fill color
      rect(posX + 16, posY + 48, 4, 4); //Draw a glove
      rect(posX + 44, posY + 48, 4, 4); //Draw a glove

      //Boots
      rect(posX + 20, posY + 60, 12, 4); //Draw a boot
      rect(posX + 36, posY + 60, 12, 4); //Draw a boot

      //Suit Badge
      fill(150, 0, 0); //Set the fill color
      rect(posX + 36, posY + 36, 4, 4); //Draw the badge

      frame++; //Increment frame
    }

    if (frame >= 30 && frame < 45) //The third set of frames
    {
      //Helmet
      fill(245); //Set the fill color
      rect(posX + 12, posY, 40, 4); //Draw a piece of the helmet
      rect(posX + 8, posY + 4, 8, 20); //Draw a piece of the helmet
      rect(posX + 16, posY + 4, 4, 4); //Draw a piece of the helmet
      rect(posX + 16, posY + 20, 4, 4); //Draw a piece of the helmet
      rect(posX + 48, posY + 4, 4, 4); //Draw a piece of the helmet
      rect(posX + 52, posY + 4, 4, 20); //Draw a piece of the helmet
      rect(posX + 48, posY + 20, 4, 4); //Draw a piece of the helmet
      rect(posX + 12, posY + 24, 40, 4); //Draw a piece of the helmet

      //Visor Glint
      rect(posX + 24, posY + 8, 4, 4); //Draw a piece of the visor glint

      //Visor Glint
      fill(210); //Set the fill color
      rect(posX + 24, posY + 12, 4, 4); //Draw a piece of the visor glint

      //Visor
      fill(215, 215, 0); //Set the fill color
      rect(posX + 20, posY + 4, 28, 4); //Draw a piece of the visor
      rect(posX + 16, posY + 8, 8, 12); //Draw a piece of the visor
      rect(posX + 28, posY + 8, 24, 12); //Draw a piece of the visor
      rect(posX + 24, posY + 16, 4, 4); //Draw a piece of the visor
      rect(posX + 20, posY + 20, 28, 4); //Draw a piece of the visor

      //Suit
      fill(225); //Set the fill color
      rect(posX + 20, posY + 28, 24, 4); //Draw a piece of the suit
      rect(posX + 16, posY + 32, 32, 4); //Draw a piece of the suit
      rect(posX + 20, posY + 36, 16, 4); //Draw a piece of the suit
      rect(posX + 40, posY + 36, 4, 4); //Draw a piece of the suit
      rect(posX + 20, posY + 40, 24, 16); //Draw a piece of the suit
      rect(posX + 20, posY + 56, 8, 4); //Draw a piece of the suit
      rect(posX + 44, posY + 52, 4, 4); //Draw a piece of the suit
      rect(posX + 40, posY + 56, 8, 4); //Draw a piece of the suit

      //Suit Arms
      fill(195); //Set the fill color
      rect(posX + 16, posY + 36, 4, 8); //Draw a piece of the suit arm
      rect(posX + 20, posY + 44, 4, 4); //Draw a piece of the suit arm
      rect(posX + 44, posY + 36, 4, 12); //Draw a suit arm

      //Gloves
      fill(115); //Set the fill color
      rect(posX + 24, posY + 48, 4, 4); //Draw a glove
      rect(posX + 44, posY + 48, 4, 4); //Draw a glove

      //Boots
      rect(posX + 20, posY + 60, 12, 4); //Draw a boot
      rect(posX + 48, posY + 48, 4, 12); //Draw a boot

      //Suit Badge
      fill(150, 0, 0); //Set the fill color
      rect(posX + 36, posY + 36, 4, 4); //Draw the badge

      frame++; //Increment frame
    }

    if (frame >= 45 && frame < 60) //The second set of frames
    {
      //Helmet
      fill(245); //Set the fill color
      rect(posX + 12, posY, 40, 4); //Draw a piece of the helmet
      rect(posX + 8, posY + 4, 8, 20); //Draw a piece of the helmet
      rect(posX + 16, posY + 4, 4, 4); //Draw a piece of the helmet
      rect(posX + 16, posY + 20, 4, 4); //Draw a piece of the helmet
      rect(posX + 48, posY + 4, 4, 4); //Draw a piece of the helmet
      rect(posX + 52, posY + 4, 4, 20); //Draw a piece of the helmet
      rect(posX + 48, posY + 20, 4, 4); //Draw a piece of the helmet
      rect(posX + 12, posY + 24, 40, 4); //Draw a piece of the helmet

      //Visor Glint
      rect(posX + 24, posY + 8, 4, 4); //Draw a piece of the visor glint

      //Visor Glint
      fill(210); //Set the fill color
      rect(posX + 24, posY + 12, 4, 4); //Draw a piece of the visor glint

      //Visor
      fill(215, 215, 0); //Set the fill color
      rect(posX + 20, posY + 4, 28, 4); //Draw a piece of the visor
      rect(posX + 16, posY + 8, 8, 12); //Draw a piece of the visor
      rect(posX + 28, posY + 8, 24, 12); //Draw a piece of the visor
      rect(posX + 24, posY + 16, 4, 4); //Draw a piece of the visor
      rect(posX + 20, posY + 20, 28, 4); //Draw a piece of the visor

      //Suit
      fill(225); //Set the fill color
      rect(posX + 20, posY + 28, 24, 4); //Draw a piece of the suit
      rect(posX + 16, posY + 32, 32, 4); //Draw a piece of the suit
      rect(posX + 20, posY + 36, 16, 4); //Draw a piece of the suit
      rect(posX + 40, posY + 36, 4, 4); //Draw a piece of the suit
      rect(posX + 20, posY + 40, 24, 16); //Draw a piece of the suit
      rect(posX + 20, posY + 56, 8, 4); //Draw a piece of the suit
      rect(posX + 36, posY + 56, 8, 4); //Draw a piece of the suit

      //Suit Arms
      fill(195); //Set the fill color
      rect(posX + 16, posY + 36, 4, 12); //Draw a suit arm
      rect(posX + 44, posY + 36, 4, 12); //Draw a suit arm

      //Gloves
      fill(115); //Set the fill color
      rect(posX + 16, posY + 48, 4, 4); //Draw a glove
      rect(posX + 44, posY + 48, 4, 4); //Draw a glove

      //Boots
      rect(posX + 20, posY + 60, 12, 4); //Draw a boot
      rect(posX + 36, posY + 60, 12, 4); //Draw a boot

      //Suit Badge
      fill(150, 0, 0); //Set the fill color
      rect(posX + 36, posY + 36, 4, 4); //Draw the badge

      frame++; //Increment frame
    }

    if (frame >= 60) //Reset the frame counter
    {
      frame = 0; //Return to the first frame
    }
  }

  public void Jump(boolean doJump) //Makes the MoonMan jump
  {
    if (doJump == true && maxJump != posY) //If the MoonMan can jump
    {
      frame = 20; //Change to the jumping frame
      posY -= 4; //Move the MoonMan up
    }
    if ((doJump == false && maxJump != posY - 128) || posY <= maxJump) //If the MoonMan cannot jump
    {
      frame = 20; //Change to the jumping frame
      posY += 4; //Move the MoonMan down
    }
  }
}
class Rocks //Rocks class
{
  int timer = 0; //Timer for rock distribution
  int runCount = 0; //How often the timer has hit its end
  int posX; //The X position of the rock
  int posY; //The Y position of the rock
  int moveX; //Move the rock in the X direction
  float innerFillColor; //The inner fill color for the rock
  float outerFillColor; //The outer fill color for the rock
  boolean moveRock = false; //If the rock should move
  boolean collide = false; //If the rock has collided with something

  Rocks(int x, int y) //Constructor
  {
    posX = x; //Set the X position of the rock
    posY = y; //Set the Y position of the rock
    moveX = x; //Set the moveX coordinates
  }

  public void Display() //Draws the rocks
  {
    if (timer < 120 - runCount && moveRock == false) //If the timer is running
    {
      timer++; //Increment the timer
    }
    if (timer >= 120 - runCount && moveRock == false) //If the timer has hit its end and the rock is not moving
    {
      innerFillColor = random(75, 151); //Randomly choose the inner fill color
      outerFillColor = random(25, 76); //Randomly choose the outer fill color

      innerFillColor = Math.round(innerFillColor); //Round the inner fill color
      outerFillColor = Math.round(outerFillColor); //Round the outer fill color

      moveRock = true; //Move the rock
      timer = 0; //Reset the timer

      if (runCount < 90) //If the runCount has not reduced the timer
      {
        runCount++; //Increment the runCount
      }
    }

    if (moveRock == true) //If the rock should move
    {
      if (moveX != -64) //If the rock can move
      {       
        fill(innerFillColor); //Set the fill color
        rect(moveX + 12, posY - 44, 28, -4); //Draw a piece of the rock
        rect(moveX + 8, posY - 40, 32, -4); //Draw a piece of the rock
        rect(moveX + 8, posY - 36, 36, -4); //Draw a piece of the rock
        rect(moveX + 4, posY - 32, 40, -4); //Draw a piece of the rock
        rect(moveX + 8, posY - 28, 40, -4); //Draw a piece of the rock
        rect(moveX + 8, posY - 24, 44, -4); //Draw a piece of the rock
        rect(moveX + 8, posY - 20, 48, -4); //Draw a piece of the rock
        rect(moveX + 4, posY - 16, 48, -4); //Draw a piece of the rock
        rect(moveX + 8, posY - 12, 52, -4); //Draw a piece of the rock
        rect(moveX + 4, posY - 8, 56, -4); //Draw a piece of the rock
        rect(moveX, posY, 64, -8); //Draw a piece of the rock

        fill(outerFillColor); //Set the fill color
        rect(moveX + 12, posY - 40, 24, -4); //Draw a piece of the rock
        rect(moveX + 12, posY - 36, 28, -4); //Draw a piece of the rock
        rect(moveX + 8, posY - 32, 32, -4); //Draw a piece of the rock
        rect(moveX + 12, posY - 28, 32, -4); //Draw a piece of the rock
        rect(moveX + 12, posY - 24, 36, -4); //Draw a piece of the rock
        rect(moveX + 12, posY - 20, 40, -4); //Draw a piece of the rock
        rect(moveX + 8, posY - 16, 40, -4); //Draw a piece of the rock
        rect(moveX + 12, posY - 12, 44, -4); //Draw a piece of the rock
        rect(moveX + 8, posY - 8, 48, -4); //Draw a piece of the rock
        rect(moveX + 4, posY, 56, -8); //Draw a piece of the rock

        if (runCount < 15) //If the game is in stage 1
        {
          moveX -= 4; //Decrement moveX
        }
        if (runCount >= 15 && runCount < 30) //If the game is in stage 2
        {
          moveX -= 8; //Decrement moveX
        }
        if (runCount >= 30 && runCount < 45) //If the game is in stage 3
        {
          moveX -= 12; //Decrement moveX
        }
        if (runCount >= 45 && runCount < 60) //If the game is in stage 4
        {
          moveX -= 16; //Decrement moveX
        }
        if (runCount >= 60 && runCount < 75) //If the game is in stage 5
        {
          moveX -= 20; //Decrement moveX
        }
        if (runCount >= 75 && runCount < 90) //If the game is in stage 6
        {
          moveX -= 24; //Decrement moveX
        }
        if (runCount >= 90) //If the game is in  stage 7
        {
          moveX -= 28; //Decrement moveX
        }
      }
      if (moveX <= -64 || collide == true) //If the rock has moved the maximum distance or has collided with something
      {
        moveX = posX; //Reset moveX
        moveRock = false; //Reset moveRock
      }
    }
  }
}
class Score //Score class
{
  MoonMan moonM; //MoonMan object
  Laser lser; //Laser object
  Rocks rock; //Rock object
  int pointTotal = 0; //Keeps the score
  int timer = 0; //Timer for the MoonMan jumping

  Score(MoonMan mMan, Laser lsr, Rocks rck) //Constructor
  {
    moonM = mMan; //Import the MoonMan object
    lser = lsr; //Import the Laser object
    rock = rck; //Import the Rocks object
  }

  public void KeepScore() //Keeps the score of the game
  {
    fill(255); //Set the fill color
    textSize(24); //Set the text size
    text("SCORE: " + pointTotal, 5, 25); //Display point total

    if (mMan.collide == true && rock.collide == true) //If the Rocks and MoonMan have collided
    {
      mMan.collide = false; //The MoonMan is no longer colliding with the rock
      pointTotal -= 250; //Decrement the point total
    }
    if (lser.collide == true && rock.collide == true) //If the Rocks and Laser have collided
    {
      pointTotal += 100; //Increment the point total
    }

    if (mMan.posY <= mMan.maxJump + 4) //If the MoonMan is at maximum jumping height
    {
      timer++; //Increment the timer
    }
    if (mMan.posY != mMan.maxJump + 4) //If the MoonMan is not at maximum jumping height
    {
      timer = 0; //Reset the timer
    }

    if (timer >= 60) //If the timer has run for 2 seconds
    {
      pointTotal -= 1; //Decrement the point total
    }
  }
}
class Terrain //Terrain class
{
  int xMax; //Maximum X coordinate of the terrain
  int yMax; //Maximum Y coordinate of the terrain
  int xMoveTerrain = 640; //The X coordinate for terrain movement
  int xMoveStars = 640; //The X coordinate for star movement
  int starTimer = 0; //The timer for star movement
  float noiseScale = .5f; //Adjusts the Perlin noise scale
  float output; //The output of the Perlin noise
  PImage ground; //The ground that was saved from the Perlin noise
  PImage stars; //The stars that were saved

  Terrain(int x, int y) //Constructor
  {
    xMax = x; //Set the maximum X coordinate of the terrain
    yMax = y; //Set the maximum Y coordinate of the terrain
  }

  public void Create() //Creates the terrain
  {
    noStroke(); //Turn off outlines
    fill(255); //Set the fill color

    for (int xStart = 0; xStart < xMax; xStart++) //Loop for the X direction
    {
      for (int yStart = 0; yStart < 328; yStart++) //Loop for the Y direction
      {
        float gaussianStars = randomGaussian(); //Generate random gaussian numbers to determine how many stars will be drawn
        float starSize = randomGaussian(); //Generate random gaussian numbers for the size of the stars

        if (gaussianStars < 0) //If the numbers for generating stars are negative
        {
          gaussianStars *= -1; //Make the number positive
        }
        if (starSize < 0) //If the numbers for star size are negative
        {
          starSize *= -1; //Make the number positive
        }

        Math.round(gaussianStars); //Round the numbers for generating stars
        Math.round(starSize); //Round the numbers for generating star size

        if (gaussianStars >= 3) //If the random numbers for stars are greater than 3
        {
          rect(xStart, yStart, starSize, starSize); //Draw a star
        }
      }
    }

    float gaussianPlanet = randomGaussian(); //Generate random gaussian numbers to determine if a planet is drawn
    if (gaussianPlanet >= 3) //If the gaussian number is high enough
    {
      fill(20, 20, 100); //Set the fill color
      rect(600, 4, 32, 4); //Create a piece of the Earth
      rect(596, 8, 40, 32); //Create a piece of the Earth
      rect(600, 40, 32, 4); //Create a piece of the Earth

      fill(20, 100, 20); //Set the fill color
      rect(600, 8, 8, 12); //Create a piece of the Earth
      rect(604, 20, 4, 8); //Create a piece of the Earth
      rect(620, 12, 8, 16); //Create a piece of the Earth
      rect(600, 36, 8, 4); //Create a piece of the Earth
      rect(604, 40, 16, 4); //Create a piece of the Earth
    }

    save("stars.png"); //Save the stars as an image

    background(0); //Reset the background color
    noiseDetail(1); //Adjusts the appearance of Perlin noise

    fill(150); //Set the fill color
    rect(0, 0, xMax, 4); //Draw a rectangle

    for (int xStart = 0; xStart < xMax; xStart++) //Loop for the X direction
    {
      for (int yStart = 4; yStart < yMax; yStart++) //Loop for the Y direction
      {
        output = noise(xStart * noiseScale, yStart * noiseScale); //Creates a Perlin noise value for the specified point
        stroke(output * 150); //Set the stroke color for the specified point
        point(xStart, yStart); //Draw the specified point
      }
    }

    save("terrain.png"); //Save the terrain as an image
    
    stars = loadImage("stars.png"); //Load the terrain image
    ground = loadImage("terrain.png"); //Load the terrain image 
  }

  public void Display() //Displays the terrain
  { 
    image(stars, xMoveStars - 640, 0); //Display the image on the screen
    image(stars, xMoveStars, 0); //Display the image behind the first image

    if (starTimer < 30) //If the timer is running
    {
      starTimer++; //Increment the timer
    }
    if (starTimer == 30) //If the timer has hit its end
    {
      if (xMoveStars > 0) //If the stars have not moved the full distance
      {
        xMoveStars--; //Move the image
      } else //If the image has moved the full distance
      {
        xMoveStars = 640; //Reset the move distance of the image
      }

      starTimer = 0; //Reset the timer
    }
    
    image(ground, xMoveTerrain - 640, 328); //Display the image on the screen
    image(ground, xMoveTerrain, 328); //Display the image behind the first image

    if (xMoveTerrain > 0) //If the ground has not moved the full distance
    {
      xMoveTerrain--; //Move the image
    } else //If the image has moved the full distance
    {
      xMoveTerrain = 640; //Reset the move distance of the image
    }
  }
}
  public void settings() {  size(640, 360); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Idzik_Random" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
