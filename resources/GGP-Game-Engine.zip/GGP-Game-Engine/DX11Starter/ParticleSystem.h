#pragma once
class ParticleSystem
{
public:
	ParticleSystem();
	~ParticleSystem();
};

